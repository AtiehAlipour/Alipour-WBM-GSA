.. _citations:
.. include:: ../CITATIONS.rst
